import { createClient } from '@supabase/supabase-js';
import toast from 'react-hot-toast';

// Attempt to load environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Check if we're in development mode
const isDevelopment = import.meta.env.DEV;

if (!supabaseUrl || !supabaseAnonKey) {
  const message = 'Supabase configuration is missing. Please connect to Supabase using the "Connect to Supabase" button.';
  if (isDevelopment) {
    console.error(message);
    toast.error(message);
  }
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

// Test the connection
supabase.from('profiles').select('count', { count: 'exact', head: true })
  .then(() => {
    if (isDevelopment) {
      console.log('Successfully connected to Supabase');
      toast.success('Connected to Supabase successfully!');
    }
  })
  .catch((error) => {
    const message = 'Failed to connect to Supabase. Please check your configuration.';
    if (isDevelopment) {
      console.error('Supabase connection error:', error);
      toast.error(message);
    }
  });